-- Unfiltered Glow - database schema. Run this ONCE in Supabase > SQL Editor, then run seed.sql.

create table if not exists settings (key text primary key, value text not null);
insert into settings (key, value) values
  ('free_shipping_threshold', '7500'),
  ('shipping_fee', '250'),
  ('whatsapp_number', '923237884234'),
  ('store_phone', '0323 7884234')
on conflict (key) do nothing;

create table if not exists products (
  id text primary key,
  name text not null,
  category text not null,
  price int not null check (price >= 0),
  size text default '',
  description text default '',
  image_url text default '',
  tint text default 'sage',
  badge text default '',
  rating numeric(2,1) default 0,
  reviews int default 0,
  sold int default 0,
  stock int not null default 0 check (stock >= 0),
  active boolean default true,
  sort int default 0,
  created_at timestamptz default now()
);

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text, email text, phone text,
  points int default 0,
  created_at timestamptz default now()
);

create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, name, email) values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)), new.email)
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

create sequence if not exists order_seq start 48214;

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_no text unique not null,
  customer_id uuid references profiles(id) on delete set null,
  name text not null, phone text not null, email text,
  address text not null, city text not null, notes text,
  subtotal int not null, discount int not null default 0, shipping int not null default 0, total int not null,
  coupon_code text,
  status text not null default 'new' check (status in ('new','confirmed','shipped','delivered','cancelled')),
  payment_method text not null default 'COD',
  points_awarded boolean default false,
  created_at timestamptz default now()
);
create index if not exists orders_created_idx on orders (created_at desc);

create table if not exists order_items (
  id bigserial primary key,
  order_id uuid not null references orders(id) on delete cascade,
  product_id text, name text not null, price int not null, qty int not null
);

create table if not exists coupons (
  code text primary key,
  type text not null check (type in ('percent','fixed')),
  value int not null check (value > 0),
  min_order int default 0,
  max_uses int,
  used int default 0,
  expires_at timestamptz,
  active boolean default true,
  note text,
  created_at timestamptz default now()
);
insert into coupons (code, type, value, note) values ('GLOW10', 'percent', 10, 'Newsletter welcome code') on conflict (code) do nothing;

create table if not exists subscribers (email text primary key, created_at timestamptz default now());

create table if not exists messages (
  id bigserial primary key,
  ticket text unique not null,
  name text, email text, topic text, order_ref text, message text,
  status text default 'open' check (status in ('open','resolved')),
  created_at timestamptz default now()
);

-- Only the server (service role key) touches these tables.
alter table settings enable row level security;
alter table products enable row level security;
alter table profiles enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table coupons enable row level security;
alter table subscribers enable row level security;
alter table messages enable row level security;

-- Atomic order placement: prices, stock, coupon and shipping are all decided here (never by the browser).
create or replace function place_order(p jsonb) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  it jsonb; prod products%rowtype; cp coupons%rowtype; q int;
  sub int := 0; disc int := 0; ship int := 0; thr int; fee int;
  v_code text := upper(nullif(trim(p->>'coupon'), ''));
  v_id uuid; v_no text; res jsonb;
begin
  if p->'items' is null or jsonb_array_length(p->'items') = 0 then raise exception 'Your bag is empty'; end if;
  for it in select * from jsonb_array_elements(p->'items') loop
    q := (it->>'qty')::int;
    if q < 1 or q > 20 then raise exception 'Invalid quantity'; end if;
    select * into prod from products where id = it->>'id' and active for update;
    if not found then raise exception 'A product in your bag is no longer available'; end if;
    if prod.stock < q then
      raise exception '% - only % left in stock', prod.name, prod.stock;
    end if;
    sub := sub + prod.price * q;
  end loop;

  if v_code is not null then
    select * into cp from coupons c where c.code = v_code;
    if not found or not cp.active then raise exception 'That discount code is not valid'; end if;
    if cp.expires_at is not null and cp.expires_at < now() then raise exception 'That discount code has expired'; end if;
    if cp.max_uses is not null and cp.used >= cp.max_uses then raise exception 'That discount code has been fully used'; end if;
    if sub < coalesce(cp.min_order, 0) then raise exception 'This code needs a minimum order of PKR %', cp.min_order; end if;
    disc := case when cp.type = 'percent' then floor(sub * cp.value / 100.0) else least(cp.value, sub) end;
  end if;

  select value::int into thr from settings where key = 'free_shipping_threshold';
  select value::int into fee from settings where key = 'shipping_fee';
  ship := case when (sub - disc) >= coalesce(thr, 7500) then 0 else coalesce(fee, 250) end;

  v_no := 'UG-' || nextval('order_seq');
  insert into orders (order_no, customer_id, name, phone, email, address, city, notes, subtotal, discount, shipping, total, coupon_code)
  values (v_no, nullif(p->>'customer_id','')::uuid, p->>'name', p->>'phone', nullif(p->>'email',''), p->>'address', p->>'city', nullif(p->>'notes',''),
          sub, disc, ship, sub - disc + ship, v_code)
  returning id into v_id;

  for it in select * from jsonb_array_elements(p->'items') loop
    q := (it->>'qty')::int;
    select * into prod from products where id = it->>'id';
    insert into order_items (order_id, product_id, name, price, qty) values (v_id, prod.id, prod.name, prod.price, q);
    update products set stock = stock - q, sold = sold + q where id = prod.id;
  end loop;
  if v_code is not null then update coupons set used = used + 1 where code = v_code; end if;

  select to_jsonb(o) || jsonb_build_object('items', (select coalesce(jsonb_agg(to_jsonb(i)), '[]'::jsonb) from order_items i where i.order_id = o.id))
    into res from orders o where o.id = v_id;
  return res;
end $$;

-- Status change: restocks on cancel, awards Glow Points (1 per PKR 100) once on delivery.
create or replace function set_order_status(p_id uuid, p_status text) returns void language plpgsql security definer set search_path = public as $$
declare o orders%rowtype; i order_items%rowtype;
begin
  select * into o from orders where id = p_id for update;
  if not found then raise exception 'Order not found'; end if;
  if p_status = 'cancelled' and o.status <> 'cancelled' then
    for i in select * from order_items where order_id = p_id loop
      update products set stock = stock + i.qty, sold = greatest(sold - i.qty, 0) where id = i.product_id;
    end loop;
    if o.coupon_code is not null then update coupons set used = greatest(used - 1, 0) where code = o.coupon_code; end if;
  elsif o.status = 'cancelled' and p_status <> 'cancelled' then
    raise exception 'A cancelled order cannot be re-opened - ask the customer to order again';
  end if;
  if p_status = 'delivered' and not o.points_awarded and o.customer_id is not null then
    update profiles set points = points + floor(o.total / 100.0) where id = o.customer_id;
    update orders set points_awarded = true where id = p_id;
  end if;
  update orders set status = p_status where id = p_id;
end $$;

-- Public bucket for product photos uploaded from the admin panel.
insert into storage.buckets (id, name, public) values ('products', 'products', true) on conflict (id) do nothing;

-- SECURITY: only the server (service role) may call these. Without this, anyone with the public anon key could.
revoke execute on function place_order(jsonb) from public, anon, authenticated;
revoke execute on function set_order_status(uuid, text) from public, anon, authenticated;
grant execute on function place_order(jsonb) to service_role;
grant execute on function set_order_status(uuid, text) to service_role;
