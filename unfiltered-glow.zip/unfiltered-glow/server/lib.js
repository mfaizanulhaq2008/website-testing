const { createClient } = require('@supabase/supabase-js');
const nodemailer = require('nodemailer');

const env = (k, d = '') => (process.env[k] || d).trim();
const db = () => (db._c ||= createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false, autoRefreshToken: false } }));
const anon = () => createClient(env('SUPABASE_URL'), env('SUPABASE_ANON_KEY'), { auth: { persistSession: false, autoRefreshToken: false } });

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pkr = n => 'PKR ' + Number(n).toLocaleString('en-US');
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(e => {
  console.error(e); res.status(e.status || 500).json({ error: e.status ? e.message : (e.message || 'Server error') });
});
const bad = (msg, status = 400) => Object.assign(new Error(msg), { status });

// Pakistani mobile: 03XXXXXXXXX / +923XXXXXXXXX -> 923XXXXXXXXX
function normPhone(p) {
  const d = String(p || '').replace(/[\s\-()]/g, '');
  let m = d.match(/^(?:\+?92|0)(3\d{9})$/);
  return m ? '92' + m[1] : null;
}
const emailOk = e => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e || '');

async function userFrom(req) {
  const t = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!t) return null;
  const { data, error } = await db().auth.getUser(t);
  return error || !data.user ? null : data.user;
}
const isAdminEmail = e => env('ADMIN_EMAILS').toLowerCase().split(',').map(s => s.trim()).filter(Boolean).includes(String(e || '').toLowerCase());
const requireUser = wrap(async (req, _res, next) => { const u = await userFrom(req); if (!u) throw bad('Please sign in', 401); req.user = u; next(); });
const requireAdmin = wrap(async (req, _res, next) => {
  const u = await userFrom(req);
  if (!u) throw bad('Please sign in', 401);
  if (!isAdminEmail(u.email)) throw bad('Admins only', 403);
  req.user = u; next();
});

// ---------- notifications ----------
let mailer;
async function sendEmail(to, subject, html) {
  if (!env('GMAIL_USER') || !env('GMAIL_APP_PASSWORD') || !to) return;
  mailer ||= nodemailer.createTransport({ service: 'gmail', auth: { user: env('GMAIL_USER'), pass: env('GMAIL_APP_PASSWORD') } });
  await mailer.sendMail({ from: `"Unfiltered Glow" <${env('GMAIL_USER')}>`, to, subject, html });
}
async function sendWhatsApp(text) {
  const key = env('CALLMEBOT_APIKEY');
  if (!key) return;
  const url = `https://api.callmebot.com/whatsapp.php?phone=${env('STORE_WHATSAPP', '923237884234')}&text=${encodeURIComponent(text)}&apikey=${key}`;
  await fetch(url);
}
function orderText(o) {
  const lines = (o.items || []).map(i => `• ${i.qty} x ${i.name} - ${pkr(i.price * i.qty)}`).join('\n');
  return `🛍️ NEW ORDER ${o.order_no}\n\nName: ${o.name}\nPhone: ${o.phone}\nCity: ${o.city}\nAddress: ${o.address}${o.notes ? '\nNotes: ' + o.notes : ''}\n\n${lines}\n\nSubtotal: ${pkr(o.subtotal)}${o.discount ? `\nDiscount (${o.coupon_code}): -${pkr(o.discount)}` : ''}\nShipping: ${o.shipping ? pkr(o.shipping) : 'FREE'}\nTOTAL: ${pkr(o.total)} (Cash on Delivery)`;
}
const waLink = text => `https://wa.me/${env('STORE_WHATSAPP', '923237884234')}?text=${encodeURIComponent(text)}`;

module.exports = { env, db, anon, esc, pkr, wrap, bad, normPhone, emailOk, userFrom, requireUser, requireAdmin, isAdminEmail, sendEmail, sendWhatsApp, orderText, waLink };
