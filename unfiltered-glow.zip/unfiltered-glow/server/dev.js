// Local development: npm install && node server/dev.js  (serves the site + API on http://localhost:3000)
require('fs').existsSync('.env') && require('fs').readFileSync('.env', 'utf8').split('\n').forEach(l => {
  const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2];
});
const express = require('express'), path = require('path');
const app = require('./app');
const root = express();
root.use(app);
root.use(express.static(path.join(__dirname, '..', 'public')));
root.get('/admin', (_q, r) => r.sendFile(path.join(__dirname, '..', 'public', 'admin', 'index.html')));
root.listen(3000, () => console.log('Unfiltered Glow running on http://localhost:3000'));
