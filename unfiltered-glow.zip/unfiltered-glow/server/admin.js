const express = require('express');
const multer = require('multer');
const { db, wrap, bad, requireAdmin } = require('./lib');

const r = express.Router();
r.use(requireAdmin);
const up = multer({ storage: multer.memoryStorage(), limits: { fileSize: 4 * 1024 * 1024 } });
const CATS = ['Hair Perfume', 'Sunscreens', 'Moisturizers', 'Facewashes', 'Serums', 'Lip Care', 'Sets'];
const TINTS = ['sage', 'honey', 'blush', 'butter', 'cream', 'olive', 'rose'];
const slug = s => String(s).toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
const ok = (res, d) => res.json(d ?? { ok: true });
const must = ({ data, error }) => { if (error) throw bad(error.message); return data; };

r.get('/me', (req, res) => ok(res, { email: req.user.email }));

// ---- dashboard ----
r.get('/stats', wrap(async (_q, res) => {
  const [orders, prods, cust, msgs, subs] = await Promise.all([
    db().from('orders').select('status,total,created_at'),
    db().from('products').select('id,name,stock').eq('active', true).lte('stock', 5).order('stock'),
    db().from('profiles').select('id', { count: 'exact', head: true }),
    db().from('messages').select('id', { count: 'exact', head: true }).eq('status', 'open'),
    db().from('subscribers').select('email', { count: 'exact', head: true }),
  ]);
  const o = must(orders), today = new Date().toDateString();
  const live = o.filter(x => x.status !== 'cancelled');
  ok(res, {
    new_orders: o.filter(x => x.status === 'new').length, total_orders: o.length,
    today_orders: o.filter(x => new Date(x.created_at).toDateString() === today).length,
    revenue_delivered: o.filter(x => x.status === 'delivered').reduce((a, x) => a + x.total, 0),
    revenue_open: live.filter(x => x.status !== 'delivered').reduce((a, x) => a + x.total, 0),
    low_stock: must(prods), customers: cust.count || 0, open_messages: msgs.count || 0, subscribers: subs.count || 0,
  });
}));

// ---- products ----
function cleanProduct(b, partial) {
  const o = {};
  const set = (k, v) => { if (v !== undefined) o[k] = v; };
  if (!partial || b.name !== undefined) { if (String(b.name || '').trim().length < 2) throw bad('Product name is required'); set('name', String(b.name).trim()); }
  if (!partial || b.category !== undefined) { if (!CATS.includes(b.category)) throw bad('Pick a valid category'); set('category', b.category); }
  if (!partial || b.price !== undefined) { const p = parseInt(b.price, 10); if (!(p >= 0)) throw bad('Enter a valid price in PKR'); set('price', p); }
  if (b.stock !== undefined) { const s = parseInt(b.stock, 10); if (!(s >= 0)) throw bad('Stock must be 0 or more'); set('stock', s); }
  for (const k of ['size', 'description', 'image_url', 'badge']) if (b[k] !== undefined) set(k, String(b[k]).slice(0, 600));
  if (b.tint !== undefined) set('tint', TINTS.includes(b.tint) ? b.tint : 'sage');
  if (b.active !== undefined) set('active', !!b.active);
  for (const k of ['rating', 'reviews', 'sold', 'sort']) if (b[k] !== undefined && b[k] !== '') set(k, +b[k] || 0);
  return o;
}
r.get('/products', wrap(async (_q, res) => ok(res, must(await db().from('products').select('*').order('sort').order('created_at')))));
r.post('/products', wrap(async (req, res) => {
  const o = cleanProduct(req.body, false);
  o.id = slug(req.body.id || o.name) || 'product-' + Date.now();
  if (o.stock === undefined) o.stock = 0;
  const { error } = await db().from('products').insert(o);
  if (error) throw bad(/duplicate/i.test(error.message) ? 'A product with this name already exists' : error.message);
  ok(res, o);
}));
r.put('/products/:id', wrap(async (req, res) => { must(await db().from('products').update(cleanProduct(req.body, true)).eq('id', req.params.id)); ok(res); }));
r.delete('/products/:id', wrap(async (req, res) => {
  const { error } = await db().from('products').delete().eq('id', req.params.id);
  if (error) throw bad('Could not delete: ' + error.message);
  ok(res);
}));
r.post('/upload', up.single('file'), wrap(async (req, res) => {
  const f = req.file;
  if (!f || !/^image\/(jpeg|png|webp)$/.test(f.mimetype)) throw bad('Upload a JPG, PNG or WEBP image (max 4 MB)');
  const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${f.mimetype.split('/')[1].replace('jpeg', 'jpg')}`;
  const { error } = await db().storage.from('products').upload(path, f.buffer, { contentType: f.mimetype });
  if (error) throw bad(error.message);
  ok(res, { url: db().storage.from('products').getPublicUrl(path).data.publicUrl });
}));

// ---- orders ----
r.get('/orders', wrap(async (req, res) => {
  let q = db().from('orders').select('*, order_items(*)').order('created_at', { ascending: false }).limit(300);
  if (req.query.status) q = q.eq('status', req.query.status);
  ok(res, must(await q));
}));
r.patch('/orders/:id/status', wrap(async (req, res) => {
  if (!['new', 'confirmed', 'shipped', 'delivered', 'cancelled'].includes(req.body.status)) throw bad('Invalid status');
  const { error } = await db().rpc('set_order_status', { p_id: req.params.id, p_status: req.body.status });
  if (error) throw bad(error.message);
  ok(res);
}));

// ---- discount codes ----
const rand = n => Array.from({ length: n }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');
function cleanCoupon(b) {
  if (!['percent', 'fixed'].includes(b.type)) throw bad('Choose percent or fixed amount');
  const value = parseInt(b.value, 10);
  if (!(value > 0) || (b.type === 'percent' && value > 100)) throw bad('Enter a valid discount value');
  return { type: b.type, value, min_order: parseInt(b.min_order, 10) || 0, max_uses: b.max_uses === '' || b.max_uses == null ? null : parseInt(b.max_uses, 10),
    expires_at: b.expires_at ? new Date(b.expires_at + 'T23:59:59').toISOString() : null, active: b.active !== false, note: String(b.note || '').slice(0, 120) };
}
r.get('/coupons', wrap(async (_q, res) => ok(res, must(await db().from('coupons').select('*').order('created_at', { ascending: false })))));
r.post('/coupons', wrap(async (req, res) => {
  const o = cleanCoupon(req.body);
  o.code = (String(req.body.code || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '')) || 'GLOW-' + rand(6);
  const { error } = await db().from('coupons').insert(o);
  if (error) throw bad(/duplicate/i.test(error.message) ? 'That code already exists' : error.message);
  ok(res, o);
}));
r.post('/coupons/bulk', wrap(async (req, res) => {
  const n = Math.min(Math.max(parseInt(req.body.count, 10) || 1, 1), 100), prefix = String(req.body.prefix || 'GLOW').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10) || 'GLOW';
  const base = cleanCoupon({ ...req.body, max_uses: req.body.max_uses || 1 });
  const rows = Array.from({ length: n }, () => ({ ...base, code: `${prefix}-${rand(6)}` }));
  must(await db().from('coupons').insert(rows));
  ok(res, { codes: rows.map(x => x.code) });
}));
r.put('/coupons/:code', wrap(async (req, res) => { must(await db().from('coupons').update(cleanCoupon(req.body)).eq('code', req.params.code)); ok(res); }));
r.delete('/coupons/:code', wrap(async (req, res) => { must(await db().from('coupons').delete().eq('code', req.params.code)); ok(res); }));

// ---- customers, messages, subscribers, settings ----
r.get('/customers', wrap(async (_q, res) => {
  const [p, o] = await Promise.all([db().from('profiles').select('*').order('created_at', { ascending: false }), db().from('orders').select('customer_id,total,status')]);
  const stat = {}; must(o).filter(x => x.customer_id && x.status !== 'cancelled').forEach(x => { const s = stat[x.customer_id] ||= { orders: 0, spent: 0 }; s.orders++; s.spent += x.total; });
  ok(res, must(p).map(c => ({ ...c, orders: stat[c.id]?.orders || 0, spent: stat[c.id]?.spent || 0 })));
}));
r.get('/messages', wrap(async (_q, res) => ok(res, must(await db().from('messages').select('*').order('created_at', { ascending: false }).limit(200)))));
r.patch('/messages/:id', wrap(async (req, res) => { must(await db().from('messages').update({ status: req.body.status === 'resolved' ? 'resolved' : 'open' }).eq('id', req.params.id)); ok(res); }));
r.get('/subscribers', wrap(async (_q, res) => ok(res, must(await db().from('subscribers').select('*').order('created_at', { ascending: false })))));
r.delete('/subscribers/:email', wrap(async (req, res) => { must(await db().from('subscribers').delete().eq('email', req.params.email)); ok(res); }));
r.get('/settings', wrap(async (_q, res) => ok(res, Object.fromEntries(must(await db().from('settings').select('*')).map(x => [x.key, x.value])))));
r.put('/settings', wrap(async (req, res) => {
  const rows = [];
  for (const k of ['free_shipping_threshold', 'shipping_fee']) if (req.body[k] !== undefined) { const v = parseInt(req.body[k], 10); if (!(v >= 0)) throw bad('Enter valid numbers'); rows.push({ key: k, value: String(v) }); }
  if (rows.length) must(await db().from('settings').upsert(rows));
  ok(res);
}));

module.exports = r;
