const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const L = require('./lib');
const { db, anon, env, wrap, bad, esc, pkr, normPhone, emailOk, userFrom, requireUser, sendEmail, sendWhatsApp, orderText, waLink } = L;

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(express.json({ limit: '100kb' }));
const limit = (max, windowMs = 60_000) => rateLimit({ windowMs, max, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many requests - please wait a minute and try again.' } });

const ART = { Serums: 'a-serum', Facewashes: 'a-pump', Moisturizers: 'a-cream', Sunscreens: 'a-spf', 'Hair Perfume': 'a-mist', 'Lip Care': 'a-balm', Sets: 'a-duo' };
const shape = p => ({ id: p.id, name: p.name, cat: p.category, price: p.price, size: p.size || '', rating: +p.rating || 0, reviews: p.reviews || 0, sold: p.sold || 0, badge: p.badge || '', img: p.image_url || '', tint: p.tint || 'sage', desc: p.description || '', art: ART[p.category] || 'a-serum', stock: p.stock });
async function settings() {
  const { data } = await db().from('settings').select('key,value');
  return Object.fromEntries((data || []).map(r => [r.key, r.value]));
}

// ---------- catalogue (loaded by every page as a script) ----------
app.get('/api/catalog.js', async (_req, res) => {
  res.type('application/javascript; charset=utf-8');
  try {
    const [{ data, error }, s] = await Promise.all([db().from('products').select('*').eq('active', true).order('sort').order('created_at'), settings()]);
    if (error) throw error;
    res.set('Cache-Control', 'public, s-maxage=20, stale-while-revalidate=120');
    res.send(`window.UG_CATALOG=${JSON.stringify(data.map(shape))};window.UG_SETTINGS=${JSON.stringify({ free_shipping_threshold: +s.free_shipping_threshold || 7500, shipping_fee: +s.shipping_fee || 250, whatsapp_number: s.whatsapp_number || '923237884234' })};`);
  } catch (e) {
    console.error('catalog', e.message);
    res.set('Cache-Control', 'no-store').send('window.UG_CATALOG=[];');
  }
});
app.get('/api/products', wrap(async (_req, res) => {
  const { data, error } = await db().from('products').select('*').eq('active', true).order('sort');
  if (error) throw error; res.json(data.map(shape));
}));

// ---------- accounts ----------
const session = (s, u) => ({ access_token: s.access_token, refresh_token: s.refresh_token, expires_at: s.expires_at, user: { id: u.id, email: u.email, name: u.user_metadata?.name || u.email.split('@')[0] } });
app.post('/api/auth/signup', limit(10), wrap(async (req, res) => {
  const { name = '', email = '', password = '' } = req.body;
  if (name.trim().length < 2) throw bad('Please enter your name');
  if (!emailOk(email)) throw bad('That email does not look right');
  if (password.length < 8) throw bad('Password must be at least 8 characters');
  const { error } = await db().auth.admin.createUser({ email: email.trim(), password, email_confirm: true, user_metadata: { name: name.trim() } });
  if (error) throw bad(/registered|exists/i.test(error.message) ? 'An account with this email already exists - please sign in' : error.message);
  const { data, error: e2 } = await anon().auth.signInWithPassword({ email: email.trim(), password });
  if (e2) throw bad(e2.message);
  res.json(session(data.session, data.user));
}));
app.post('/api/auth/login', limit(15), wrap(async (req, res) => {
  const { data, error } = await anon().auth.signInWithPassword({ email: String(req.body.email || '').trim(), password: String(req.body.password || '') });
  if (error) throw bad('Wrong email or password', 401);
  res.json({ ...session(data.session, data.user), is_admin: L.isAdminEmail(data.user.email) });
}));
app.post('/api/auth/magic', limit(5), wrap(async (req, res) => {
  const email = String(req.body.email || '').trim();
  if (!emailOk(email)) throw bad('That email does not look right');
  const { error } = await anon().auth.signInWithOtp({ email, options: { emailRedirectTo: env('SITE_URL') + '/index.html', shouldCreateUser: true } });
  if (error) throw bad(error.message);
  res.json({ ok: true });
}));
app.post('/api/auth/forgot', limit(5), wrap(async (req, res) => {
  const email = String(req.body.email || '').trim();
  if (!emailOk(email)) throw bad('That email does not look right');
  await anon().auth.resetPasswordForEmail(email, { redirectTo: env('SITE_URL') + '/index.html' });
  res.json({ ok: true });
}));
app.post('/api/auth/reset', limit(10), wrap(async (req, res) => {
  const { access_token, password = '' } = req.body;
  if (password.length < 8) throw bad('Password must be at least 8 characters');
  const { data, error } = await db().auth.getUser(access_token || '');
  if (error || !data.user) throw bad('This reset link has expired - request a new one', 401);
  const r = await db().auth.admin.updateUserById(data.user.id, { password });
  if (r.error) throw bad(r.error.message);
  res.json({ ok: true });
}));
app.post('/api/auth/refresh', limit(60), wrap(async (req, res) => {
  const { data, error } = await anon().auth.refreshSession({ refresh_token: String(req.body.refresh_token || '') });
  if (error || !data.session) throw bad('Session expired', 401);
  res.json(session(data.session, data.user));
}));
app.get('/api/auth/me', requireUser, wrap(async (req, res) => {
  const { data: p } = await db().from('profiles').select('*').eq('id', req.user.id).maybeSingle();
  res.json({ id: req.user.id, email: req.user.email, name: p?.name || req.user.user_metadata?.name || req.user.email.split('@')[0], phone: p?.phone || '', points: p?.points || 0, is_admin: L.isAdminEmail(req.user.email) });
}));
app.patch('/api/auth/me', requireUser, wrap(async (req, res) => {
  const upd = {}; if (req.body.name) upd.name = String(req.body.name).slice(0, 80); if (req.body.phone) upd.phone = String(req.body.phone).slice(0, 20);
  await db().from('profiles').update(upd).eq('id', req.user.id); res.json({ ok: true });
}));

// ---------- discount codes ----------
function couponDiscount(cp, sub) {
  if (!cp || !cp.active) throw bad('That discount code is not valid');
  if (cp.expires_at && new Date(cp.expires_at) < new Date()) throw bad('That discount code has expired');
  if (cp.max_uses != null && cp.used >= cp.max_uses) throw bad('That discount code has been fully used');
  if (sub < (cp.min_order || 0)) throw bad(`This code needs a minimum order of ${pkr(cp.min_order)}`);
  return cp.type === 'percent' ? Math.floor(sub * cp.value / 100) : Math.min(cp.value, sub);
}
app.post('/api/coupons/validate', limit(30), wrap(async (req, res) => {
  const code = String(req.body.code || '').trim().toUpperCase(), sub = +req.body.subtotal || 0;
  const { data } = await db().from('coupons').select('*').eq('code', code).maybeSingle();
  const discount = couponDiscount(data, sub);
  res.json({ code, discount, label: data.type === 'percent' ? `${data.value}% off` : `${pkr(data.value)} off` });
}));

// ---------- orders (Cash on Delivery) ----------
app.post('/api/orders', limit(8), wrap(async (req, res) => {
  const b = req.body || {};
  const name = String(b.name || '').trim(), address = String(b.address || '').trim(), city = String(b.city || '').trim();
  const phone = normPhone(b.phone), email = String(b.email || '').trim();
  if (name.length < 2) throw bad('Please enter your full name');
  if (!phone) throw bad('Please enter a valid Pakistani mobile number (e.g. 0323 7884234)');
  if (city.length < 2) throw bad('Please enter your city');
  if (address.length < 8) throw bad('Please enter your complete delivery address');
  if (email && !emailOk(email)) throw bad('That email does not look right');
  const merged = {};
  for (const it of Array.isArray(b.items) ? b.items : []) { const q = parseInt(it.qty, 10); if (it.id && q > 0) merged[it.id] = (merged[it.id] || 0) + q; }
  const items = Object.entries(merged).map(([id, qty]) => ({ id, qty }));
  if (!items.length) throw bad('Your bag is empty');
  const user = await userFrom(req);
  const { data: order, error } = await db().rpc('place_order', { p: { name, phone, email, address, city, notes: String(b.notes || '').slice(0, 500), items, coupon: b.coupon || '', customer_id: user?.id || '' } });
  if (error) throw bad(error.message);
  const text = orderText(order);
  const rows = order.items.map(i => `<tr><td>${i.qty} × ${esc(i.name)}</td><td align="right">${pkr(i.price * i.qty)}</td></tr>`).join('');
  const html = `<div style="font-family:Arial,sans-serif;max-width:520px"><h2>Order ${esc(order.order_no)}</h2><p><b>${esc(order.name)}</b><br>${esc(order.phone)}${order.email ? '<br>' + esc(order.email) : ''}<br>${esc(order.address)}, ${esc(order.city)}${order.notes ? '<br><i>' + esc(order.notes) + '</i>' : ''}</p><table width="100%" cellpadding="6">${rows}</table><p>Subtotal ${pkr(order.subtotal)}${order.discount ? `<br>Discount (${esc(order.coupon_code)}) -${pkr(order.discount)}` : ''}<br>Shipping ${order.shipping ? pkr(order.shipping) : 'FREE'}<br><b>Total ${pkr(order.total)} - Cash on Delivery</b></p></div>`;
  await Promise.allSettled([
    sendEmail(env('STORE_EMAIL', 'unfilteredglow.pk@gmail.com'), `🛍️ New order ${order.order_no} - ${pkr(order.total)}`, html),
    email ? sendEmail(email, `Your Unfiltered Glow order ${order.order_no}`, html.replace('<h2>', '<p>Thank you for your order! We will confirm it on WhatsApp shortly. Pay cash when it arrives.</p><h2>')) : null,
    sendWhatsApp(text),
  ]);
  res.json({ order: { order_no: order.order_no, subtotal: order.subtotal, discount: order.discount, shipping: order.shipping, total: order.total }, whatsapp_url: waLink(text) });
}));
app.get('/api/orders/mine', requireUser, wrap(async (req, res) => {
  const { data, error } = await db().from('orders').select('order_no,status,total,created_at,order_items(name,qty)').eq('customer_id', req.user.id).order('created_at', { ascending: false }).limit(20);
  if (error) throw error; res.json(data);
}));

// ---------- newsletter & contact ----------
app.post('/api/newsletter', limit(6), wrap(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  if (!emailOk(email)) throw bad('Please enter a valid email address');
  const { error } = await db().from('subscribers').upsert({ email }, { onConflict: 'email' });
  if (error) throw error;
  await sendEmail(email, 'Welcome to the Glow List ✨', '<div style="font-family:Arial,sans-serif"><h2>Welcome to Unfiltered Glow</h2><p>Here is your 10% welcome code:</p><h1>GLOW10</h1><p>Use it at checkout on your first ritual.</p></div>').catch(() => {});
  res.json({ ok: true, code: 'GLOW10' });
}));
const TOPICS = { order: 'My order', routine: 'Skincare routine', ingredients: 'Ingredients', partnerships: 'Partnerships' };
app.post('/api/contact', limit(5), wrap(async (req, res) => {
  const b = req.body || {};
  if (b.website) throw bad('Message could not be sent');
  const name = String(b.name || '').trim(), email = String(b.email || '').trim(), message = String(b.message || '').trim();
  if (name.length < 2) throw bad('Please enter your name');
  if (!emailOk(email)) throw bad('That email does not look right');
  if (message.length < 5) throw bad('Please write a short message');
  const row = { name, email, topic: TOPICS[b.topic] ? b.topic : 'order', order_ref: String(b.order || '').slice(0, 60), message: message.slice(0, 1200) };
  let ticket, error;
  for (let i = 0; i < 4; i++) {
    ticket = 'UG-C-' + Math.floor(10000 + Math.random() * 89999);
    ({ error } = await db().from('messages').insert({ ...row, ticket }));
    if (!error) break;
  }
  if (error) throw error;
  const html = `<div style="font-family:Arial,sans-serif;max-width:520px"><h3>Care desk ${ticket}</h3><p><b>${esc(name)}</b> (${esc(email)})<br>Topic: ${TOPICS[row.topic]}${row.order_ref ? '<br>Order: ' + esc(row.order_ref) : ''}</p><p>${esc(row.message).replace(/\n/g, '<br>')}</p></div>`;
  await Promise.allSettled([
    sendEmail(env('STORE_EMAIL', 'unfilteredglow.pk@gmail.com'), `Care desk ${ticket}: ${TOPICS[row.topic]}`, html),
    sendEmail(email, `We got your message (${ticket})`, `<div style="font-family:Arial,sans-serif"><p>Hi ${esc(name.split(' ')[0])}, thank you for writing to Unfiltered Glow. Your ticket is <b>${ticket}</b>. We reply within 24 hours.</p></div>`),
    sendWhatsApp(`💬 Care desk ${ticket}\n${name} (${email})\n${TOPICS[row.topic]}\n${row.message.slice(0, 300)}`),
  ]);
  res.json({ ticket });
}));

app.use('/api/admin', require('./admin'));
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));
module.exports = app;
