# Unfiltered Glow — store + backend

Frontend (your design, unchanged) in `public/`, API in `server/` (Express), database on **Supabase**, hosting on **Vercel**.
Payments: **Cash on Delivery** only · Currency: **PKR** · Delivery: Pakistan (from Faisalabad).

## 1. Supabase (10 min)
1. Create a project at supabase.com.
2. **SQL Editor** → paste `supabase/schema.sql` → Run. Then paste `supabase/seed.sql` → Run (adds your 16 products; **prices are placeholders** — edit them in the admin panel).
3. **Project Settings → API**: copy the Project URL, `anon` key and `service_role` key (keep the service key secret).
4. **Authentication → URL Configuration**: set *Site URL* to your website URL and add `https://YOUR-SITE/**` to *Redirect URLs* (needed for login-link and password-reset emails).
5. **Authentication → SMTP Settings** (recommended, otherwise Supabase limits login emails to ~2/hour): enable custom SMTP → host `smtp.gmail.com`, port `465`, user `unfilteredglow.pk@gmail.com`, password = a Gmail **App Password**.

## 2. Gmail App Password
Google Account → Security → turn on 2-Step Verification → App passwords → create one. Used for order / contact emails.

## 3. Deploy to Vercel
1. Push this folder to GitHub (or run `npx vercel` in it).
2. Import in Vercel → Framework: **Other** → deploy.
3. **Settings → Environment Variables**: add everything from `.env.example` (`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `SITE_URL`, `ADMIN_EMAILS`, `GMAIL_USER`, `GMAIL_APP_PASSWORD`, `STORE_EMAIL`, `STORE_WHATSAPP`). Redeploy.

## 4. Admin panel → `https://YOUR-SITE/admin`
Create your account on the site (Account → Create account) using **unfilteredglow.pk@gmail.com** (it must be listed in `ADMIN_EMAILS`), then sign in at `/admin`. You can:
- see/confirm/ship/cancel orders (cancelling returns stock), WhatsApp or call the customer in one tap; a sound + badge alerts you to new orders
- add / edit / hide / delete products, upload photos, set stock (sold-out items can't be bought; stock is checked again at checkout)
- create discount codes (percent or fixed PKR, minimum order, max uses, expiry) and bulk-generate one-time codes; `GLOW10` already exists
- see customers (with Glow Points: 1 point per PKR 100, awarded when an order is marked *delivered*), care-desk messages, newsletter subscribers, and change shipping settings

## 5. Orders → WhatsApp
- After checkout the customer gets a **"Confirm on WhatsApp"** button that opens WhatsApp to **0323 7884234** with the full order pre-written.
- Every order also appears in `/admin` and is emailed to unfilteredglow.pk@gmail.com.
- **Optional automatic WhatsApp to you** for every order (no customer click needed): follow callmebot.com/blog/free-api-whatsapp-messages (send one message to the bot), then put your key in `CALLMEBOT_APIKEY`. Leave empty to skip. (The official WhatsApp Business API is the paid alternative.)

## Run locally
`npm install`, copy `.env.example` to `.env` and fill it in, then `node server/dev.js` → http://localhost:3000

## Good to know
- Shipping defaults: free over PKR 7,500, otherwise PKR 250 (change in Admin → Settings). Seed prices are old USD prices × 100.
- Account sign-up does not verify the email (the "email me a login link" option does).
- Product photos from Unsplash are placeholders — replace with your own in Admin → Products.
- The Contact page still says opening hours "PT" (Pacific time); change it to Pakistan time in `public/contact.html`.
