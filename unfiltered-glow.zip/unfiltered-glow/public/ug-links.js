/* Unfiltered Glow: About page ko khud jodta hai.
   Har page mein bas ek line: <script src="ug-links.js" defer></script>
   Ye khud karta hai:
   1) Header, mobile menu aur footer ke "About / Our Story" links ko about page par le jata hai
   2) Har page par sahi menu item ko "active" dikhata hai */
(function () {
  'use strict';

  /* Agar aap ke about page ka naam alag ho to sirf yahan badlein */
  const ABOUT_PAGE = 'about.html';

  const D = document;
  const file = p => (p.split('/').pop() || 'index.html').split('?')[0].split('#')[0];
  const base = f => f.replace(/\.html$/i, '').toLowerCase() || 'index';

  /* 1) Purane "index.html#about" aur "#about" links ko about page par bhej dein */
  D.querySelectorAll('a[href]').forEach(a => {
    const h = a.getAttribute('href');
    if (h === 'index.html#about' || h === '/#about' || h === './index.html#about') {
      a.setAttribute('href', ABOUT_PAGE);
    }
  });

  /* 2) Active menu: jis page par hain us ka link highlight ho.
        product-detail page par "Shop" active rahega */
  let here = base(file(location.pathname));
  if (here === 'product-detail') here = 'shop';

  const mark = (sel, useClass) => D.querySelectorAll(sel).forEach(a => {
    const h = a.getAttribute('href') || '';
    if (h.includes('#')) return;               /* #contact jaise links ko chhor dein */
    const on = base(file(h)) === here;
    if (useClass) a.classList.toggle('active', on);
    if (on) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
  mark('.nav .nav__link', true);
  mark('.m-nav a', false);

  /* Mobile menu ke active item ke liye halka style */
  const st = D.createElement('style');
  st.textContent = '.m-nav a[aria-current="page"]{color:var(--olive-d);background:var(--cream2)}';
  D.head.appendChild(st);
})();
