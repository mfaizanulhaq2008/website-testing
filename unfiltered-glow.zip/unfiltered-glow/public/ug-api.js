/* Unfiltered Glow - backend connector. Loaded on every page after the existing site scripts.
   It hooks the existing cart / profile / newsletter UI to the real API, without changing the design. */
(function () {
  'use strict';
  const W = window, D = document, UG = W.UG;
  if (!UG) return;
  const S = Object.assign({ free_shipping_threshold: 7500, shipping_fee: 250, whatsapp_number: '923237884234' }, W.UG_SETTINGS || {});
  const money = n => 'PKR ' + Number(n).toLocaleString('en-US');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toast = (m, o) => UG.toast(m, o || {});
  const stop = e => { e.preventDefault(); e.stopImmediatePropagation(); };
  const emailOk = v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v || '');

  /* ---------- auth tokens + fetch helper ---------- */
  const TK = 'ug-auth';
  const tok = () => { try { return JSON.parse(localStorage.getItem(TK) || 'null'); } catch (e) { return null; } };
  const setTok = t => { try { t ? localStorage.setItem(TK, JSON.stringify(t)) : localStorage.removeItem(TK); } catch (e) {} };
  async function api(path, opt, retry) {
    opt = opt || {}; const t = tok(), h = { 'Content-Type': 'application/json' };
    if (t) h.Authorization = 'Bearer ' + t.access_token;
    const r = await fetch('/api' + path, { method: opt.method || 'GET', headers: h, body: opt.body ? JSON.stringify(opt.body) : undefined });
    if (r.status === 401 && t && t.refresh_token && retry !== false) {
      const rr = await fetch('/api/auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: t.refresh_token }) });
      if (rr.ok) { setTok(await rr.json()); return api(path, opt, false); }
      setTok(null);
    }
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (!r.ok) throw new Error(j.error || 'Something went wrong. Please try again.');
    return j;
  }
  W.UGApi = api;

  /* ---------- styles ---------- */
  const st = D.createElement('style');
  st.textContent = `
.ug-modal{position:fixed;inset:0;z-index:10000;display:flex;align-items:center;justify-content:center;padding:14px;background:rgba(58,47,39,.55);backdrop-filter:blur(4px);opacity:0;transition:opacity .3s}
.ug-modal.open{opacity:1}
.ug-box{position:relative;background:var(--cream2);color:var(--brown);border-radius:22px;max-width:540px;width:100%;max-height:94vh;overflow:auto;padding:28px 26px;box-shadow:var(--sh3);transform:translateY(18px);transition:transform .45s var(--e)}
.ug-modal.open .ug-box{transform:none}
.ug-box h3{font:600 30px/1.1 var(--serif);margin:0 0 4px;color:var(--olive-k)}
.ug-sub{font-size:13px;color:var(--brown-s);margin:0 0 18px}
.ug-x{position:absolute;top:12px;right:14px;width:34px;height:34px;border-radius:50%;border:0;background:var(--cream3);color:var(--brown);font-size:20px;cursor:pointer}
.ug-f{margin:0 0 12px}.ug-f label{display:block;font:600 10.5px var(--sans);letter-spacing:.14em;text-transform:uppercase;color:var(--brown-s);margin:0 0 6px}
.ug-f input,.ug-f textarea{width:100%;box-sizing:border-box;padding:13px 14px;border:1px solid var(--line);border-radius:12px;background:#fff;font:400 15px var(--sans);color:var(--brown)}
.ug-f input:focus,.ug-f textarea:focus{outline:2px solid var(--sage);border-color:var(--olive)}
.ug-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:520px){.ug-row{grid-template-columns:1fr}}
.ug-code{display:flex;gap:8px}.ug-code input{flex:1}
.ug-sum{background:var(--cream);border-radius:14px;padding:14px 16px;margin:6px 0 14px;font-size:14px}
.ug-sum div{display:flex;justify-content:space-between;padding:3px 0}.ug-sum .t{border-top:1px solid var(--line);margin-top:6px;padding-top:9px;font-weight:600;font-size:16px;color:var(--olive-k)}
.ug-err{color:var(--danger);font-size:13px;min-height:18px;margin:0 0 10px}
.ug-ok{color:var(--olive-d);font-size:13px;margin:0 0 10px}
.ug-done{text-align:center}.ug-done .ok{display:inline-flex;width:62px;height:62px;border-radius:50%;background:var(--sage-t);color:var(--olive-d);align-items:center;justify-content:center;font-size:30px;margin-bottom:10px}
.ug-done .no{font:600 22px var(--serif);background:var(--cream);border-radius:12px;padding:10px;margin:12px 0;letter-spacing:.06em}
.ug-done .btn{margin:5px 3px}
.ug-tabs{display:flex;gap:6px;margin:0 0 14px;background:var(--cream3);padding:4px;border-radius:999px}.ug-tabs button{flex:1;border:0;background:none;padding:10px;border-radius:999px;font:600 11px var(--sans);letter-spacing:.12em;text-transform:uppercase;color:var(--brown-s);cursor:pointer}.ug-tabs button.on{background:var(--olive-d);color:var(--cream2)}
.ug-alt{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:12px}.ug-alt button{background:none;border:0;color:var(--olive-d);text-decoration:underline;font:500 13px var(--sans);cursor:pointer;padding:4px 0}
.ug-orders{margin-top:18px;border-top:1px solid var(--line);padding-top:14px;font-size:13px}.ug-orders h4{font:600 11px var(--sans);letter-spacing:.14em;text-transform:uppercase;color:var(--brown-s);margin:0 0 8px}
.ug-orders li{list-style:none;display:flex;justify-content:space-between;gap:8px;padding:7px 0;border-bottom:1px dashed var(--line)}.ug-orders ul{margin:0;padding:0}.ug-orders em{font-style:normal;text-transform:capitalize;color:var(--olive-d)}
.ug-so{opacity:.55;pointer-events:auto;filter:grayscale(.4)}
.ug-wa{position:fixed;left:16px;bottom:18px;z-index:80;width:52px;height:52px;border-radius:50%;background:#25a05a;color:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 10px 26px rgba(37,160,90,.4);transition:transform .35s var(--e)}
.ug-wa:hover{transform:scale(1.08) translateY(-2px)}.ug-wa svg{width:26px;height:26px}
`;
  D.head.appendChild(st);

  /* ---------- helpers that talk to the existing core script ---------- */
  const cart = () => UG.state.cart;
  const inCart = id => cart().filter(l => l.id === id).reduce((a, l) => a + l.qty, 0);
  const subtotal = () => cart().reduce((a, l) => a + l.price * l.qty, 0);
  function clearCart() {
    cart().length = 0;
    try { const s = JSON.parse(localStorage.getItem('ug-state') || '{}'); s.cart = []; localStorage.setItem('ug-state', JSON.stringify(s)); } catch (e) {}
    UG.sync();
  }
  // Signs the core script's own "user" in, by replaying its original profile form with a flag we let through.
  function coreLogin(name, email) {
    D.querySelectorAll('#profileForm').forEach(f => f.remove());
    const f = D.createElement('form'); f.id = 'profileForm'; f.hidden = true;
    f.innerHTML = '<input id="pName"><input id="pEmail"><p id="pNameErr"></p><p id="pEmailErr"></p>';
    D.body.appendChild(f);
    f.querySelector('#pName').value = (name && name.length > 1 ? name : (email || 'Friend').split('@')[0]);
    f.querySelector('#pEmail').value = email;
    W.__ugPass = true; f.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })); W.__ugPass = false;
    f.remove();
  }
  function modal(html, cls) {
    const m = D.createElement('div'); m.className = 'ug-modal ' + (cls || '');
    m.innerHTML = '<div class="ug-box"><button class="ug-x" aria-label="Close" type="button">&times;</button>' + html + '</div>';
    D.body.appendChild(m); requestAnimationFrame(() => m.classList.add('open'));
    const close = () => { m.classList.remove('open'); setTimeout(() => m.remove(), 300); };
    m.addEventListener('click', e => { if (e.target === m || e.target.closest('.ug-x') || e.target.closest('[data-ug-close]')) close(); });
    return { el: m, box: m.firstChild, close };
  }

  /* ---------- checkout (Cash on Delivery) ---------- */
  const CITIES = ['Faisalabad', 'Lahore', 'Karachi', 'Islamabad', 'Rawalpindi', 'Multan', 'Gujranwala', 'Sialkot', 'Peshawar', 'Quetta', 'Hyderabad', 'Sargodha', 'Bahawalpur', 'Jhang', 'Sahiwal', 'Okara', 'Gujrat', 'Sheikhupura', 'Chiniot', 'Toba Tek Singh', 'Mardan', 'Abbottabad'];
  function openCheckout() {
    if (!cart().length) { toast('Your bag is empty', { icon: 'alert' }); return; }
    UG.close();
    let saved = {}; try { saved = JSON.parse(localStorage.getItem('ug-ship') || '{}'); } catch (e) {}
    const u = UG.state.user || {};
    let coupon = '', disc = 0, busy = false;
    const M = modal(`<h3>Checkout</h3><p class="ug-sub">Cash on Delivery · delivered across Pakistan from Faisalabad</p>
<form id="ugCo" novalidate>
 <div class="ug-row"><div class="ug-f"><label for="coN">Full name</label><input id="coN" autocomplete="name" value="${esc(saved.name || u.name || '')}"></div>
 <div class="ug-f"><label for="coP">Mobile / WhatsApp</label><input id="coP" type="tel" inputmode="tel" autocomplete="tel" placeholder="0323 7884234" value="${esc(saved.phone || '')}"></div></div>
 <div class="ug-row"><div class="ug-f"><label for="coC">City</label><input id="coC" list="ugCities" autocomplete="address-level2" value="${esc(saved.city || 'Faisalabad')}"><datalist id="ugCities">${CITIES.map(c => '<option value="' + c + '">').join('')}</datalist></div>
 <div class="ug-f"><label for="coE">Email (optional)</label><input id="coE" type="email" autocomplete="email" placeholder="for your receipt" value="${esc(saved.email || u.email || '')}"></div></div>
 <div class="ug-f"><label for="coA">Complete delivery address</label><textarea id="coA" rows="2" autocomplete="street-address" placeholder="House #, street, area / mohallah">${esc(saved.address || '')}</textarea></div>
 <div class="ug-f"><label for="coT">Order notes (optional)</label><input id="coT" placeholder="e.g. call before delivery"></div>
 <div class="ug-f"><label for="coD">Discount code</label><div class="ug-code"><input id="coD" placeholder="GLOW10" autocapitalize="characters"><button class="btn btn--ghost btn--sm" type="button" id="coApply">APPLY</button></div></div>
 <div class="ug-sum" id="coSum"></div>
 <p class="ug-err" id="coErr" role="alert"></p>
 <button class="btn btn--primary" type="submit" id="coGo" style="width:100%;justify-content:center">PLACE ORDER · CASH ON DELIVERY</button>
</form>`);
    const $ = s => M.box.querySelector(s);
    const calc = () => { const sub = subtotal(), ship = (sub - disc) >= S.free_shipping_threshold ? 0 : S.shipping_fee; return { sub, ship, total: sub - disc + ship }; };
    const paint = () => { const c = calc(); $('#coSum').innerHTML = `<div><span>Subtotal</span><span>${money(c.sub)}</span></div>${disc ? `<div><span>Discount (${esc(coupon)})</span><span>-${money(disc)}</span></div>` : ''}<div><span>Shipping</span><span>${c.ship ? money(c.ship) : 'FREE'}</span></div><div class="t"><span>Total to pay on delivery</span><span>${money(c.total)}</span></div>`; };
    paint();
    $('#coApply').onclick = async () => {
      const code = $('#coD').value.trim(); if (!code) return; const err = $('#coErr'); err.className = 'ug-err'; err.textContent = '';
      try { const r = await api('/coupons/validate', { method: 'POST', body: { code, subtotal: subtotal() } }); coupon = r.code; disc = r.discount; paint(); err.className = 'ug-ok'; err.textContent = '✓ ' + r.label + ' applied'; }
      catch (e) { coupon = ''; disc = 0; paint(); err.textContent = e.message; }
    };
    $('#ugCo').addEventListener('submit', async e => {
      e.preventDefault(); if (busy) return;
      const err = $('#coErr'); err.className = 'ug-err'; err.textContent = '';
      const body = { name: $('#coN').value, phone: $('#coP').value, city: $('#coC').value, email: $('#coE').value, address: $('#coA').value, notes: $('#coT').value, coupon: coupon || $('#coD').value.trim(), items: cart().map(l => ({ id: l.id, qty: l.qty })) };
      busy = true; const b = $('#coGo'); b.disabled = true; b.textContent = 'PLACING YOUR ORDER…';
      try {
        const r = await api('/orders', { method: 'POST', body });
        try { localStorage.setItem('ug-ship', JSON.stringify({ name: body.name, phone: body.phone, city: body.city, email: body.email, address: body.address })); } catch (x) {}
        clearCart(); showDone(M, r);
      } catch (x) { err.textContent = x.message; b.disabled = false; b.textContent = 'PLACE ORDER · CASH ON DELIVERY'; busy = false; }
    });
  }
  function showDone(M, r) {
    const o = r.order;
    M.box.innerHTML = `<button class="ug-x" aria-label="Close" type="button">&times;</button><div class="ug-done"><span class="ok">✓</span><h3>Order placed!</h3>
<p class="ug-sub">Thank you — we will confirm your order on WhatsApp. Please keep <b>${money(o.total)}</b> ready in cash for the rider.</p>
<div class="no">${esc(o.order_no)}</div>
<a class="btn btn--primary" target="_blank" rel="noopener" href="${esc(r.whatsapp_url)}">CONFIRM ON WHATSAPP</a>
<button class="btn btn--ghost" type="button" data-ug-close>CONTINUE SHOPPING</button></div>`;
    toast('Order ' + o.order_no + ' placed', { icon: 'check' });
  }

  /* ---------- accounts (password or email login link) ---------- */
  function authNode() {
    const n = D.createElement('div'); n.className = 'ug-auth'; let mode = 'in';
    n.innerHTML = `<div class="ug-tabs"><button type="button" data-m="in" class="on">Sign in</button><button type="button" data-m="up">Create account</button></div>
<form novalidate><div class="ug-f" data-up hidden><label>First name</label><input id="ugN" autocomplete="given-name"></div>
<div class="ug-f"><label>Email</label><input id="ugE" type="email" autocomplete="email" placeholder="you@example.com"></div>
<div class="ug-f"><label>Password</label><input id="ugP" type="password" autocomplete="current-password" placeholder="At least 8 characters"></div>
<p class="ug-err" role="alert"></p><button class="btn btn--primary" type="submit" id="ugGo">SIGN IN</button></form>
<div class="ug-alt"><button type="button" id="ugMagic">Email me a login link</button><button type="button" id="ugForgot">Forgot password?</button></div>`;
    const q = s => n.querySelector(s), err = q('.ug-err');
    const say = (m, good) => { err.className = good ? 'ug-ok' : 'ug-err'; err.textContent = m; };
    n.querySelectorAll('[data-m]').forEach(b => b.onclick = () => {
      mode = b.dataset.m; n.querySelectorAll('[data-m]').forEach(x => x.classList.toggle('on', x === b));
      q('[data-up]').hidden = mode !== 'up'; q('#ugGo').textContent = mode === 'up' ? 'CREATE MY ACCOUNT' : 'SIGN IN'; q('#ugP').autocomplete = mode === 'up' ? 'new-password' : 'current-password'; say('');
    });
    q('form').onsubmit = async e => {
      e.preventDefault(); const email = q('#ugE').value.trim(), password = q('#ugP').value, name = q('#ugN').value.trim();
      if (mode === 'up' && name.length < 2) return say('Please enter your name');
      if (!emailOk(email)) return say('That email does not look right');
      if (password.length < (mode === 'up' ? 8 : 1)) return say(mode === 'up' ? 'Password must be at least 8 characters' : 'Enter your password');
      const b = q('#ugGo'); b.disabled = true; say('');
      try {
        const s = await api(mode === 'up' ? '/auth/signup' : '/auth/login', { method: 'POST', body: { name, email, password } });
        setTok({ access_token: s.access_token, refresh_token: s.refresh_token }); coreLogin(s.user.name, s.user.email);
      } catch (x) { say(x.message); b.disabled = false; }
    };
    q('#ugMagic').onclick = async () => {
      const email = q('#ugE').value.trim(); if (!emailOk(email)) return say('Enter your email above first');
      try { await api('/auth/magic', { method: 'POST', body: { email } }); say('✓ Check your inbox — we sent you a login link.', true); } catch (x) { say(x.message); }
    };
    q('#ugForgot').onclick = async () => {
      const email = q('#ugE').value.trim(); if (!emailOk(email)) return say('Enter your email above first');
      try { await api('/auth/forgot', { method: 'POST', body: { email } }); say('✓ If that account exists, a reset link is on its way.', true); } catch (x) { say(x.message); }
    };
    return n;
  }
  async function ordersNode() {
    const wrap = D.createElement('div'); wrap.className = 'ug-orders';
    try {
      const [me, list] = await Promise.all([api('/auth/me'), api('/orders/mine')]);
      wrap.innerHTML = `<h4>Glow Points: <b>${me.points}</b></h4>` + (list.length ? '<h4 style="margin-top:12px">Your orders</h4><ul>' + list.map(o => `<li><span>${esc(o.order_no)} · <em>${esc(o.status)}</em></span><span>${money(o.total)}</span></li>`).join('') + '</ul>' : '<p style="color:var(--brown-s)">No orders yet — your first ritual awaits.</p>');
    } catch (e) { return null; }
    return wrap;
  }
  const pb = D.getElementById('profileBody');
  if (pb) new MutationObserver(() => {
    const f = pb.querySelector('#profileForm');
    if (f) f.replaceWith(authNode());
    else if (pb.querySelector('#signOut') && !pb.querySelector('.ug-orders') && tok()) { pb.dataset.ugO = '1'; ordersNode().then(n => { if (n && !pb.querySelector('.ug-orders')) pb.appendChild(n); }); }
  }).observe(pb, { childList: true });

  /* ---------- global click / submit hooks (capture phase = run before the core handlers) ---------- */
  function stockGuard(id, e) {
    const p = UG.P(id); if (!p || typeof p.stock !== 'number') return false;
    if (p.stock <= 0) { stop(e); toast('Sorry, ' + p.name + ' is sold out', { icon: 'alert' }); return true; }
    if (inCart(id) + 1 > p.stock) { stop(e); toast('Only ' + p.stock + ' left in stock', { icon: 'alert' }); return true; }
    return false;
  }
  W.addEventListener('click', e => {
    const a = e.target.closest('[data-add]'); if (a && stockGuard(a.dataset.add, e)) return;
    const d = e.target.closest('[data-key][data-d="1"]'); if (d && stockGuard(d.dataset.key.split('::')[0], e)) return;
    if (e.target.closest('#checkoutBtn')) { stop(e); openCheckout(); return; }
    if (e.target.closest('#signOut')) setTok(null);
  }, true);

  const nlDone = new WeakSet();
  W.addEventListener('submit', async e => {
    if (W.__ugPass) return;
    const f = e.target;
    if (f.id === 'profileForm') { stop(e); return; }
    if (f.classList && f.classList.contains('nl-form') && !nlDone.has(f)) {
      const inp = f.querySelector('input'), v = (inp.value || '').trim();
      if (!emailOk(v)) return;              // let the core show its own "valid email" message
      stop(e);
      try { await api('/newsletter', { method: 'POST', body: { email: v } }); } catch (x) { toast(x.message, { icon: 'alert' }); return; }
      nlDone.add(f); W.__ugPass = true; f.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })); W.__ugPass = false;
    }
  }, true);

  /* ---------- sold-out labels, hide empty ratings ---------- */
  let raf = 0;
  function decorate() {
    D.querySelectorAll('[data-add]').forEach(b => {
      const p = UG.P(b.dataset.add); if (!p || typeof p.stock !== 'number' || p.stock > 0 || b.dataset.ugSo) return;
      b.dataset.ugSo = '1'; b.classList.add('ug-so'); const sp = b.querySelector('span'); (sp || b).textContent = 'SOLD OUT';
    });
    D.querySelectorAll('.p-rate').forEach(r => { if (/^\s*0\.0/.test(r.textContent)) r.style.display = 'none'; });
  }
  new MutationObserver(() => { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; decorate(); }); }).observe(D.body, { childList: true, subtree: true });
  decorate();

  /* ---------- login links from email (magic link / password reset) ---------- */
  function showReset(accessToken) {
    const M = modal(`<h3>Set a new password</h3><p class="ug-sub">Choose a password with at least 8 characters.</p><form><div class="ug-f"><label>New password</label><input type="password" id="rpP" autocomplete="new-password"></div><p class="ug-err" id="rpE"></p><button class="btn btn--primary" type="submit">SAVE PASSWORD</button></form>`);
    M.box.querySelector('form').onsubmit = async e => {
      e.preventDefault();
      try { await api('/auth/reset', { method: 'POST', body: { access_token: accessToken, password: M.box.querySelector('#rpP').value } }); M.close(); toast('Password updated — please sign in', { icon: 'check' }); setTimeout(() => UG.open('profile'), 400); }
      catch (x) { M.box.querySelector('#rpE').textContent = x.message; }
    };
  }
  const h = location.hash.replace(/^#/, '');
  let fromLink = false;
  if (/access_token=|error_description=/.test(h)) {
    const p = new URLSearchParams(h); history.replaceState(null, '', location.pathname + location.search);
    if (p.get('error_description')) toast(p.get('error_description').replace(/\+/g, ' '), { icon: 'alert' });
    else if (p.get('type') === 'recovery') showReset(p.get('access_token'));
    else { setTok({ access_token: p.get('access_token'), refresh_token: p.get('refresh_token') }); fromLink = true; }
  }
  if (UG.state.user && !tok() && !sessionStorage.getItem('ug-fix')) {   // old browser-only "accounts" from before the backend existed
    try { const s = JSON.parse(localStorage.getItem('ug-state') || '{}'); delete s.user; localStorage.setItem('ug-state', JSON.stringify(s)); } catch (e) {}
    sessionStorage.setItem('ug-fix', '1'); location.reload(); return;
  }
  if (fromLink) api('/auth/me').then(me => coreLogin(me.name, me.email)).catch(() => setTok(null));

  /* ---------- WhatsApp chat button ---------- */
  const wa = D.createElement('a'); wa.className = 'ug-wa'; wa.target = '_blank'; wa.rel = 'noopener'; wa.setAttribute('aria-label', 'Chat on WhatsApp');
  wa.href = 'https://wa.me/' + S.whatsapp_number + '?text=' + encodeURIComponent('Hi Unfiltered Glow! I need help with…');
  wa.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3.5a8.5 8.5 0 0 0-7.3 12.8L3.5 20.5l4.3-1.1A8.5 8.5 0 1 0 12 3.5z"/><path d="M9 8.6c.2 2.9 2.4 5.1 5.4 5.4l1-1.2-1.8-.9-.8.6c-.9-.4-1.6-1.1-2-2l.6-.8-.9-1.8z" fill="currentColor" stroke="none"/></svg>';
  D.body.appendChild(wa);
})();
