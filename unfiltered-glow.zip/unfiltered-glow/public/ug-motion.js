/* Unfiltered Glow - scroll animations that replay every time you scroll (down AND back up).
   Elements fade/slide in from below when scrolling down and from above when scrolling back up. */
(function () {
  'use strict';
  const D = document, W = window;
  if (!('IntersectionObserver' in W) || W.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const st = D.createElement('style');
  st.textContent =
    '.reveal:not(.in){transform:translate3d(0,var(--ug-y,28px),0)}' +
    '.ug-rv{opacity:0;transform:translate3d(0,var(--ug-y,34px),0);transition:opacity .85s ease,transform .95s cubic-bezier(.22,.61,.21,1);transition-delay:var(--ug-d,0s);will-change:transform,opacity}' +
    '.ug-rv.ug-in{opacity:1;transform:none}';
  D.head.appendChild(st);

  let lastY = W.scrollY, dir = 'down';
  W.addEventListener('scroll', () => { const y = W.scrollY; if (Math.abs(y - lastY) > 2) { dir = y < lastY ? 'up' : 'down'; lastY = y; } }, { passive: true });

  const io = new IntersectionObserver(es => es.forEach(en => {
    const el = en.target, cls = el.classList.contains('reveal') ? 'in' : 'ug-in';
    if (en.isIntersecting) {
      el.style.setProperty('--ug-y', dir === 'up' ? '-34px' : '34px');
      el.classList.add(cls);
    } else if (en.boundingClientRect.top > 0 || en.boundingClientRect.bottom < 0 || true) {
      el.classList.remove(cls);          // leaves the screen -> resets, so it animates again next time it appears
    }
  }), { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });

  const SEL = '.reveal,.p-card,.foot-grid>*,.shop-hero .wrap>*,.closing .wrap>*,.newsletter .wrap>*';
  const seen = new WeakSet();
  function scan(root) {
    (root || D).querySelectorAll(SEL).forEach((el, i) => {
      if (seen.has(el)) return; seen.add(el);
      if (!el.classList.contains('reveal')) { el.classList.add('ug-rv'); el.style.setProperty('--ug-d', Math.min(i % 4, 3) * 0.07 + 's'); }
      io.observe(el);
    });
  }
  scan();
  let raf = 0;
  new MutationObserver(() => { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; scan(); }); }).observe(D.body, { childList: true, subtree: true });
})();
