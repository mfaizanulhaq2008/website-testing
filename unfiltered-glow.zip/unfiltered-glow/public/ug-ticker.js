/* Unfiltered Glow: upar ki chalti hui hari patti (ticker) kisi bhi page par laga deta hai.
   Page mein bas ek line: <script src="ug-ticker.js" defer></script>
   Jis page par ticker pehle se hai (index, shop) wahan ye kuch nahi karta. */
(function () {
  'use strict';
  const D = document, W = window;
  if (D.querySelector('.ticker')) return;

  const H = 38; /* patti ki unchai (px) */
  const ITEMS = ['HAIR PERFUME', 'SUNSCREENS', 'MOISTURIZERS', 'FACEWASHES', 'SERUMS', 'LIP CARE', 'FAST DELIVERY ACROSS PAKISTAN', 'CLEAN INGREDIENTS'];

  /* ---- Style ---- */
  const st = D.createElement('style');
  st.textContent =
    '.ticker{background:#454B33;color:#F2EDE2;overflow:hidden;height:' + H + 'px;display:flex;align-items:center}' +
    '.ticker__track{display:flex;width:max-content;animation:ugTick var(--td,32s) linear infinite;will-change:transform}' +
    '.ticker:hover .ticker__track{animation-play-state:paused}' +
    '.ticker__group{display:flex;align-items:center;flex:none}' +
    '.ticker__item{font:600 10.5px/1 var(--sans,"Plus Jakarta Sans",system-ui,sans-serif);letter-spacing:.24em;padding:0 18px;white-space:nowrap}' +
    '.ticker__sep{color:#D9A9A0;font-size:10px}' +
    '@keyframes ugTick{to{transform:translate3d(calc(-1 * var(--tw,50%)),0,0)}}' +
    /* fixed header ko patti ke neeche rakhta hai, scroll par upar chipak jata hai */
    '.site-header{top:var(--hdr-top,0px)}' +
    '.mobile-menu{top:calc(var(--header-h,84px) + var(--hdr-top,0px))}' +
    '@media(prefers-reduced-motion:reduce){.ticker{overflow-x:auto}.ticker__track{animation:none!important}}';
  D.head.appendChild(st);

  /* ---- Markup ---- */
  const group = '<div class="ticker__group" id="ugTickerGroup">' +
    ITEMS.map(t => '<span class="ticker__sep">\u2022</span><span class="ticker__item">' + t + '</span>').join('') +
    '<span class="ticker__sep">\u2022</span></div>';
  const tk = D.createElement('div');
  tk.className = 'ticker';
  tk.setAttribute('aria-label', 'Store announcements');
  tk.innerHTML = '<div class="ticker__track" id="ugTickerTrack">' + group + '</div>';
  D.body.insertBefore(tk, D.body.firstChild);

  const track = D.getElementById('ugTickerTrack');
  const first = D.getElementById('ugTickerGroup');

  /* ---- Seamless loop: group ko itni baar clone karta hai ke screen bhar jaye ---- */
  function build() {
    track.querySelectorAll('[data-clone]').forEach(n => n.remove());
    const gw = first.getBoundingClientRect().width;
    if (!gw) return;
    track.style.setProperty('--tw', gw + 'px');
    track.style.setProperty('--td', Math.max(14, gw / 70) + 's');
    const n = Math.max(1, Math.ceil((W.innerWidth * 2) / gw));
    for (let i = 0; i < n; i++) {
      const c = first.cloneNode(true);
      c.removeAttribute('id');
      c.setAttribute('data-clone', '');
      c.setAttribute('aria-hidden', 'true');
      track.appendChild(c);
    }
  }
  build();
  if (D.fonts && D.fonts.ready) D.fonts.ready.then(build);
  let t;
  W.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(build, 200); });

  /* ---- Fixed header: patti ke neeche se shuru, scroll par top par chipak jaye ---- */
  const header = D.querySelector('.site-header');
  if (header && getComputedStyle(header).position === 'fixed') {
    const root = D.documentElement;
    const upd = () => root.style.setProperty('--hdr-top', Math.max(0, H - W.scrollY) + 'px');
    W.addEventListener('scroll', upd, { passive: true });
    upd();
  }
})();
