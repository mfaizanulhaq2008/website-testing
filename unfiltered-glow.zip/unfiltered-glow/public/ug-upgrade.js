/* Unfiltered Glow: upgrade layer. shop.html ke </body> se pehle: <script src="ug-upgrade.js" defer></script> */
(function () {
  'use strict';
  const D = document;
  const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---- Fallback product illustrations (image load na ho to ye dikhte hain) ---- */
  const ART = {
    'Serums': '<rect x="46" y="62" width="40" height="60" rx="10"/><rect x="54" y="44" width="24" height="18" rx="3"/><path d="M60 44V26a6 6 0 0 1 12 0v18M58 84h16M58 94h16"/>',
    'Facewashes': '<path d="M42 40h48l-4 78H46Z"/><rect x="50" y="26" width="32" height="14" rx="3"/><path d="M52 70h28"/>',
    'Moisturizers': '<rect x="34" y="62" width="64" height="52" rx="12"/><rect x="38" y="44" width="56" height="18" rx="6"/><path d="M50 88h32"/>',
    'Sunscreens': '<path d="M44 52h44l-3 66H47Z"/><rect x="52" y="34" width="28" height="18" rx="4"/><circle cx="66" cy="86" r="9"/><path d="M66 70v-3M66 105v-3M50 86h-3M85 86h-3"/>',
    'Hair Perfume': '<rect x="42" y="64" width="48" height="58" rx="14"/><rect x="58" y="50" width="16" height="14" rx="2"/><path d="M52 50h28M66 50V32h14M90 32h8M92 26l7-3M92 38l7 3"/>',
    'Lip Care': '<rect x="48" y="66" width="36" height="54" rx="6"/><rect x="48" y="40" width="36" height="26" rx="6"/><path d="M54 40V30a12 12 0 0 1 24 0v10"/>'
  };
  const kind = s => {
    s = (s || '').toLowerCase();
    return /spf|sunscreen|veil/.test(s) ? 'Sunscreens'
      : /hair|mist|perfume/.test(s) ? 'Hair Perfume'
      : /lip|balm/.test(s) ? 'Lip Care'
      : /serum|oil|drop/.test(s) ? 'Serums'
      : /wash|toner|cleans/.test(s) ? 'Facewashes'
      : 'Moisturizers';
  };
  const art = c => '<svg viewBox="0 0 132 148" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="width:44%;max-width:150px;opacity:.78">' +
    ART[c] + '<ellipse cx="66" cy="134" rx="34" ry="4" fill="currentColor" stroke="none" opacity=".12"/></svg>';

  /* ---- Har image ko monitor karein: load, error, aur 8s timeout ---- */
  function arm(img) {
    if (img.dataset.ug) return;
    img.dataset.ug = '1';
    const ph = img.closest('.ph, .mini-shot');
    if (!ph) return;
    let t;
    const ok = () => { clearTimeout(t); ph.classList.remove('ph--broken'); img.classList.add('is-loaded'); };
    const bad = () => {
      const fb = ph.querySelector('.ph-fallback');
      if (fb && !fb.dataset.art) { fb.dataset.art = '1'; fb.innerHTML = art(kind(img.alt)); }
      ph.classList.add('ph--broken');
    };
    img.addEventListener('load', ok);
    img.addEventListener('error', () => { clearTimeout(t); bad(); });
    if (img.complete && img.naturalWidth > 0) ok();
    else t = setTimeout(bad, 8000); // slow/blocked network par bhi khali box nahi rahega
  }
  const scan = () => D.querySelectorAll('.ph img, .mini-shot img').forEach(arm);

  /* Cart count bug: drawer title mein function ka text aa raha tha (count vs count()) */
  const fixCount = () => {
    const dc = D.getElementById('drawerCount'), cb = D.getElementById('cartBadge');
    if (dc && cb && dc.textContent.length > 8) dc.textContent = '(' + cb.textContent + ')';
  };

  let raf = 0;
  new MutationObserver(() => {
    if (raf) return;
    raf = requestAnimationFrame(() => { raf = 0; scan(); fixCount(); });
  }).observe(D.body, { childList: true, subtree: true });
  scan();

  /* ---- Scroll progress line ---- */
  const pb = D.createElement('div');
  pb.className = 'ug-progress';
  D.body.appendChild(pb);
  const upd = () => {
    const h = D.documentElement.scrollHeight - innerHeight;
    pb.style.transform = 'scaleX(' + (h > 0 ? Math.min(1, scrollY / h) : 0) + ')';
  };
  addEventListener('scroll', upd, { passive: true });
  addEventListener('resize', upd);
  upd();

  /* ---- Active tab hamesha beech mein (mobile par bohat kaam ka) ---- */
  const tabs = D.getElementById('tabs');
  D.addEventListener('click', e => {
    if (!tabs || !e.target.closest('[data-cat]')) return;
    setTimeout(() => {
      const a = tabs.querySelector('.tab.active');
      if (a) tabs.scrollTo({ left: a.offsetLeft - (tabs.clientWidth - a.offsetWidth) / 2, behavior: RM ? 'auto' : 'smooth' });
    }, 30);
  });
})();
