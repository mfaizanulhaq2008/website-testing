// Vercel serverless entry: every /api/* request lands here.
module.exports = require('../server/app');
